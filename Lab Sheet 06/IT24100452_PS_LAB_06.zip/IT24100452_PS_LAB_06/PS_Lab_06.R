
#Q1(1)
# Binomial distribution with n =50 , p =0.85
n <-50
p <-0.85

#Q1(2)
# P(X>=47) =1-P(X<=46)
prob_at_least_47 <- 1 - pbinom(46,n,p)
print(prob_at_least_47)

#Q2 (1)
#1) X is the number of calls  received in an hour

#Q2 (2) Poisson distribution with lambda = 12
lambda <-12

#Q2 3)
prob_exactly_15 <- dpois(15,lambda)
print(prob_exactly_15)